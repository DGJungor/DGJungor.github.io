Before submitting an issue, please search for the issue [here](https://github.com/theme-next/hexo-theme-next/issues?utf8=%E2%9C%93&q=) to find if the issue is already reported.

Also, you can search for answers on the [«NexT» Documentation Site](https://theme-next.org):

- FAQs (Work in progress)
